package myfirstjavaprogram;
import java.util.Scanner;
public class myfirstclass {
	public static void main(String args[]) 
	{ char r;
	 do{
		System.out.println("**********Library Management System*************");
		System.out.println("Enter 1 to add book");
		System.out.println("Enter 2 to issue a book");
		System.out.println("Enter 3 to return a book");
		System.out.println("Enter 4 to print complete issue details");
		System.out.println("Enter 5 to exit");
		Scanner obj1= new Scanner(System.in);
		System.out.println("Enter any Number");
		int a= obj1.nextInt();
		switch(a)
		{
		case 1:
			Library aa= new Library();
			aa.add();
			break;
		case 2:
			Library bb= new Library();
			bb.iss();
			break;
		case 3:
			Library cc= new Library();
			cc.ret();
			break;
		case 4:
			Library is= new Library();
			is.detail();
			break;
		case 5:
			Library add= new Library();
			add.exit();
			break;
			default:
				System.out.println("invalid number");
		}
		System.out.println("You want to select next option y/n");
		r=obj1.next().charAt(0);
	 }
		while(r=='y'||r=='Y');
		if(r=='n'||r=='N');
		{
			Library z= new Library();
			z.exit();
		}
		
		
		}
	
	}
class Library{
	  static String str,b,date;
		static int a,c;
		void add() {
			System.out.println("Enter  book name & prize & book no");
			Scanner obj2= new Scanner(System.in);
			String str=obj2.nextLine();
		    float price=obj2.nextInt();
		    int bookno=obj2.nextInt();
		    System.out.println("Your details is: ");
		    System.out.println("book name:"+str);
		    System.out.println("price:"+price);
		    System.out.println("book num:"+bookno);
		    
		}
	

void iss(){
	Scanner obj3= new Scanner(System.in);
	System.out.println("book name");
    str=obj3.nextLine();
	System.out.println("book id");
	a=obj3.nextInt();
	obj3.nextLine();
	System.out.println("issue date");
	b=obj3.nextLine();
	System.out.println("Total no of books issued");
	c=obj3.nextInt();
	obj3.nextLine();
	System.out.println("Return book date");
	date=obj3.nextLine();
}
int getid(){
	return a;
}

void ret(){
	System.out.println("Enter student name & book id");
	Scanner c = new Scanner(System.in);
	String name= c.nextLine();
	int bookid=c.nextInt();
	if(a==bookid){
		System.out.println("Total details");
		System.out.println("Book name:"+Library.str);
		System.out.println("book id :"+Library.a);
		System.out.println("Issue date:" +Library.b);
		System.out.println("Total no of book issued:"+Library.c);
		System.out.println("Book return date:"+Library.date);
		
	}
	else{
		System.out.println("wrong id ,please enter correct id");
	}
}

void detail(){
	System.out.println("Total details");
	System.out.println("Book name:"+Library.str);
	System.out.println("book id :"+Library.a);
	System.out.println("Issue date:" +Library.b);
	System.out.println("Total no of book issued:"+Library.c);
	System.out.println("Book return date:"+Library.date);
	}
void exit(){
	System.exit(0);
}
}
	
    
	
	